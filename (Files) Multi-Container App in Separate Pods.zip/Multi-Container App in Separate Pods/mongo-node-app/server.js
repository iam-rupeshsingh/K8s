const express = require("express");
const mongoose = require("mongoose");

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static("public"));

mongoose.connect("mongodb://mongo:27017/emailDB")
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

const emailSchema = new mongoose.Schema({
  email: String
});

const Email = mongoose.model("Email", emailSchema);

// Save email
app.post("/save", async (req, res) => {
  const newEmail = new Email({ email: req.body.email });
  await newEmail.save();
  res.redirect("/");
});

// Fetch emails
app.get("/emails", async (req, res) => {
  const emails = await Email.find();
  res.json(emails);
});

// ← Add /exit route HERE, above app.listen()
app.get("/exit", (req, res) => {
  res.send("Server is shutting down...");
  console.log("Shutting down server via /exit");
  setTimeout(() => {
    process.exit(0);
  }, 1000);
});


app.listen(3000, () => {
  console.log("Server running on port 3000");
});

